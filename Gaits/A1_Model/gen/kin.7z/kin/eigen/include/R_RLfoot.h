/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:41 GMT-04:00
 */

#ifndef R_RLFOOT_H
#define R_RLFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_RLfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


