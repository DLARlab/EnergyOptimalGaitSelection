/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:33 GMT-04:00
 */

#ifndef R_BASEROTZ_H
#define R_BASEROTZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_BaseRotZ(const Eigen::Matrix<double,18,1> &var1);

#endif 


