/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:39 GMT-04:00
 */

#ifndef JP_BASEROTX_H
#define JP_BASEROTX_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,18> Jp_BaseRotX(const Eigen::Matrix<double,18,1> &var1);

#endif 


