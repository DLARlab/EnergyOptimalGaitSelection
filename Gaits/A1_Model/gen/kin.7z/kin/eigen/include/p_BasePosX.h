/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:19 GMT-04:00
 */

#ifndef P_BASEPOSX_H
#define P_BASEPOSX_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BasePosX(const Eigen::Matrix<double,18,1> &var1);

#endif 


