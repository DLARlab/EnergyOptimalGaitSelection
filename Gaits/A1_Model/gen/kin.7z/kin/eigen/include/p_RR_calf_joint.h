/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:12 GMT-04:00
 */

#ifndef P_RR_CALF_JOINT_H
#define P_RR_CALF_JOINT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_RR_calf_joint(const Eigen::Matrix<double,18,1> &var1);

#endif 


