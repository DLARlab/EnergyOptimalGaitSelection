/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:14 GMT-04:00
 */

#ifndef R_RR_CALF_JOINT_H
#define R_RR_CALF_JOINT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_RR_calf_joint(const Eigen::Matrix<double,18,1> &var1);

#endif 


