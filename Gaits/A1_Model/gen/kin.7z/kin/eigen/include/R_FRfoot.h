/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:30 GMT-04:00
 */

#ifndef R_FRFOOT_H
#define R_FRFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_FRfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


