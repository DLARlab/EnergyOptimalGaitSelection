/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:31 GMT-04:00
 */

#ifndef JP_BASEROTZ_H
#define JP_BASEROTZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,18> Jp_BaseRotZ(const Eigen::Matrix<double,18,1> &var1);

#endif 


