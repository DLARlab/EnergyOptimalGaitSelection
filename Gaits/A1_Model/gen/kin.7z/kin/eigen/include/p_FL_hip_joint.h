/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:53 GMT-04:00
 */

#ifndef P_FL_HIP_JOINT_H
#define P_FL_HIP_JOINT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_FL_hip_joint(const Eigen::Matrix<double,18,1> &var1);

#endif 


