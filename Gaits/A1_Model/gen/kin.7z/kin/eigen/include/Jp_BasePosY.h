/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:24 GMT-04:00
 */

#ifndef JP_BASEPOSY_H
#define JP_BASEPOSY_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,18> Jp_BasePosY(const Eigen::Matrix<double,18,1> &var1);

#endif 


