/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:13 GMT-04:00
 */

#ifndef H_RR_CALF_JOINT_H
#define H_RR_CALF_JOINT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_RR_calf_joint(const Eigen::Matrix<double,18,1> &var1);

#endif 


