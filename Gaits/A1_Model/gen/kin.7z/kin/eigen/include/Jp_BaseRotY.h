/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:35 GMT-04:00
 */

#ifndef JP_BASEROTY_H
#define JP_BASEROTY_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,18> Jp_BaseRotY(const Eigen::Matrix<double,18,1> &var1);

#endif 


