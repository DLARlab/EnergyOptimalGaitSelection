/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:36 GMT-04:00
 */

#ifndef H_BASEROTY_H
#define H_BASEROTY_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_BaseRotY(const Eigen::Matrix<double,18,1> &var1);

#endif 


