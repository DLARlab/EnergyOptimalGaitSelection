/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:22 GMT-04:00
 */

#ifndef R_BASEPOSX_H
#define R_BASEPOSX_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_BasePosX(const Eigen::Matrix<double,18,1> &var1);

#endif 


