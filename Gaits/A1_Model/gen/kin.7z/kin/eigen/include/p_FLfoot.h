/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:30 GMT-04:00
 */

#ifndef P_FLFOOT_H
#define P_FLFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_FLfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


