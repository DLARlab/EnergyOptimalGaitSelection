/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:33 GMT-04:00
 */

#ifndef R_FLFOOT_H
#define R_FLFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_FLfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


