/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:10 GMT-04:00
 */

#ifndef H_RR_THIGH_JOINT_H
#define H_RR_THIGH_JOINT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_RR_thigh_joint(const Eigen::Matrix<double,18,1> &var1);

#endif 


