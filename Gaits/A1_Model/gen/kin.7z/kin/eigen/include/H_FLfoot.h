/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:32 GMT-04:00
 */

#ifndef H_FLFOOT_H
#define H_FLFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_FLfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


