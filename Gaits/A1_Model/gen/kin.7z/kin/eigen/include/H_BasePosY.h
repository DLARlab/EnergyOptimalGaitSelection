/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:25 GMT-04:00
 */

#ifndef H_BASEPOSY_H
#define H_BASEPOSY_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_BasePosY(const Eigen::Matrix<double,18,1> &var1);

#endif 


