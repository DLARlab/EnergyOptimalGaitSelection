/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:42 GMT-04:00
 */

#ifndef P_VECTORNAV_H
#define P_VECTORNAV_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_VectorNav(const Eigen::Matrix<double,18,1> &var1);

#endif 


