/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:03:37 GMT-04:00
 */

#ifndef R_RRFOOT_H
#define R_RRFOOT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_RRfoot(const Eigen::Matrix<double,18,1> &var1);

#endif 


