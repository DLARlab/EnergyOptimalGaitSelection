/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:29 GMT-04:00
 */

#ifndef R_BASEPOSZ_H
#define R_BASEPOSZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_BasePosZ(const Eigen::Matrix<double,18,1> &var1);

#endif 


