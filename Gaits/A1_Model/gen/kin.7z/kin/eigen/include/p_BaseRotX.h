/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:38 GMT-04:00
 */

#ifndef P_BASEROTX_H
#define P_BASEROTX_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BaseRotX(const Eigen::Matrix<double,18,1> &var1);

#endif 


