/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:34 GMT-04:00
 */

#ifndef P_BASEROTY_H
#define P_BASEROTY_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BaseRotY(const Eigen::Matrix<double,18,1> &var1);

#endif 


