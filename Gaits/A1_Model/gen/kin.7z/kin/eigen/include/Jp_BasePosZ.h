/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:27 GMT-04:00
 */

#ifndef JP_BASEPOSZ_H
#define JP_BASEPOSZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,18> Jp_BasePosZ(const Eigen::Matrix<double,18,1> &var1);

#endif 


