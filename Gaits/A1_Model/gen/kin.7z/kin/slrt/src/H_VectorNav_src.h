/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:17 GMT-04:00
 */

#ifndef H_VECTORNAV_SRC_H
#define H_VECTORNAV_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void H_VectorNav_src(double *p_output1, const double *var1);

#endif 
/* H_VECTORNAV_SRC_H */
