/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:01:23 GMT-04:00
 */

#ifndef H_FR_CALF_JOINT_SRC_H
#define H_FR_CALF_JOINT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void H_FR_calf_joint_src(double *p_output1, const double *var1);

#endif 
/* H_FR_CALF_JOINT_SRC_H */
