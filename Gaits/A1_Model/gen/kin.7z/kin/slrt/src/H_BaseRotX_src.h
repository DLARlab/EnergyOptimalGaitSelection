/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:01:11 GMT-04:00
 */

#ifndef H_BASEROTX_SRC_H
#define H_BASEROTX_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void H_BaseRotX_src(double *p_output1, const double *var1);

#endif 
/* H_BASEROTX_SRC_H */
