/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:01:49 GMT-04:00
 */

#ifndef JP_RL_HIP_JOINT_SRC_H
#define JP_RL_HIP_JOINT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void Jp_RL_hip_joint_src(double *p_output1, const double *var1);

#endif 
/* JP_RL_HIP_JOINT_SRC_H */
