/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:01:27 GMT-04:00
 */

#ifndef H_FL_HIP_JOINT_SRC_H
#define H_FL_HIP_JOINT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void H_FL_hip_joint_src(double *p_output1, const double *var1);

#endif 
/* H_FL_HIP_JOINT_SRC_H */
