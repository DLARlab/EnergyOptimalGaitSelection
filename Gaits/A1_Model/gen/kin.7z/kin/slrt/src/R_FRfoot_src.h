/*
 * Automatically Generated from Mathematica.
 * Mon 22 Mar 2021 16:02:02 GMT-04:00
 */

#ifndef R_FRFOOT_SRC_H
#define R_FRFOOT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void R_FRfoot_src(double *p_output1, const double *var1);

#endif 
/* R_FRFOOT_SRC_H */
